document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (e) {
        const startInput = document.getElementById("start_time");
        const endInput = document.getElementById("end_time");

        const startDate = new Date(startInput.value);
        const endDate = new Date(endInput.value);

        // Normalize all to minutes precision
        const now = new Date();
        now.setSeconds(0, 0);
        startDate.setSeconds(0, 0);
        endDate.setSeconds(0, 0);

        if (startDate < now) {
            alert("Auction start time cannot be in the past.");
            e.preventDefault();
            return;
        }

        if (endDate <= startDate) {
            alert("Auction end time must be after the start time.");
            e.preventDefault();
            return;
        }
    });
});
